/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial_2;

/**
 *
 * @author delij
 */
class Especialidad {
    private int codigo;
    private String nombre;

  
    public Especialidad(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

 
    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }
}
