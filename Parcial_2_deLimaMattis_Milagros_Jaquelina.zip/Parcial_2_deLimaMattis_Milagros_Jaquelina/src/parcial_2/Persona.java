/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial_2;

/**
 *
 * @author delij
 */
abstract class Persona {
    private String nombre;
    private String apellido;
    private int edad;
    private boolean activo;
    public Persona(String nombre, String apellido, int edad, boolean activo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.activo = activo;
    }
    class Profesional extends Persona {
    private String especialidad;

    // Constructor
    public Profesional(String nombre, String apellido, int edad, boolean activo, String especialidad) {
        super(nombre, apellido, edad, activo);
        this.especialidad = especialidad;
    }

    // Método getter para especialidad
    public String getEspecialidad() {
        return especialidad;
    }
}
    class Paciente extends Persona {
    private String obraSocial;

    // Constructor
    public Paciente(String nombre, String apellido, int edad, boolean activo, String obraSocial) {
        super(nombre, apellido, edad, activo);
        this.obraSocial = obraSocial;
    }

    // Método getter para obra social
    public String getObraSocial() {
        return obraSocial;
    }
}
}
