/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial_2;

/**
 *
 * @author delij
 */
public class Recursos {
       private String nombre;
    private int cantidad;

    // Constructor
    public Recursos(String nombre, int cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    // Métodos getters
    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }
}
