/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial_2;

/**
 *
 * @author delij
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

// Clase que representa un turno con su información
class Turno {
    private int numeroTurno;
    private String especialidad;
    private String nombrePaciente;
    private String secretaria;
    private String fecha;

    public Turno(int numeroTurno, String especialidad, String nombrePaciente, String secretaria, String fecha) {
        this.numeroTurno = numeroTurno;
        this.especialidad = especialidad;
        this.nombrePaciente = nombrePaciente;
        this.secretaria = secretaria;
        this.fecha = fecha;
    }

    public int getNumeroTurno() {
        return numeroTurno;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public String getSecretaria() {
        return secretaria;
    }

    public String getFecha() {
        return fecha;
    }
    
}
